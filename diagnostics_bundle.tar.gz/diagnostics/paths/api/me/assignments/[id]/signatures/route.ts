import { cookies } from "next/headers";
import { NextResponse } from "next/server";

const API_BASE =
  process.env.API_BASE_URL ?? "https://api.blaueengelhaushaltshilfe.de";

export async function POST(
  req: Request,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  const cookieStore = await cookies();
  const token = cookieStore.get("be_access")?.value;

  if (!token) {
    return NextResponse.json({ message: "Nicht autorisiert" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  if (!body?.signatureData) {
    return NextResponse.json(
      { message: "Unterschrift ist erforderlich" },
      { status: 400 }
    );
  }

  const upstreamRes = await fetch(`${API_BASE}/me/assignments/${id}/signatures`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({ signatureData: body.signatureData }),
    cache: "no-store",
  });

  const data = await upstreamRes.json().catch(() => ({}));
  return NextResponse.json(data, { status: upstreamRes.status });
}
